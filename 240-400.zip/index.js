(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_1", frames: [[242,0,193,279],[0,0,240,400]]},
		{name:"index_atlas_NP_1", frames: [[0,0,240,400]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.box = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.fon = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.fon1 = function() {
	this.initialize(ss["index_atlas_NP_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Egq9AUVMAAAgopMBV7AAAMAAAAopg");
	mask.setTransform(275,130.1);

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkAEzQgJAAgGgGQgHgHAAgLQgBgLAGgIQAHgJALgBIACAAQAXgBAUgNQANgOACgUQADgrgBgmIAAj6QABgpgEgqQgBgTgNgNQgVgMgWgCQgYgEgBgWQAAgcAhAAIEIAAQBmAAA3AaQBPAkAABZQAAB3isAOQDEAHAACWQAABbhGAuQg7AnhcAAIk6gCgAghANQgGAQACARIAAB5QgBAbAEAaQACASAOALQASAMAXgBQAxAAAZghQAZgiAAg4QABghgPghQgQgdgbgTQgOgLgTgFQgXgDgVAAQgQAAgFAJgAAQkCQgkAAgNAOQgEAEAAArIAABsQgBAPACAPQABAHAHACQALACAOAAQBjAAAAhxQADgogYgfQgLgNgQgHQgOgGgQAAIgCAAg");
	this.shape.setTransform(198.4109,121.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvElQgTgYgGgfIgFAFQg5A9g6AAQgcACgUgRQgVgVgJgdQgEgMgGgMQgGgKgHAHIgbAbQgdAfgmAXQhEAqg9ghQg/giAAhUQAAg4AhgtQAbglA2ghICdheQAPgKABgDQABgCAAgUIAAg2QAAgtgFgVQgKgpggAAQgvAAgcBVQgHAUgLAWQgRAdg/ATQhCAVAAguQAAgfAYgmQAUghAbgYQBQhHB1AAQBUAAApAjQAtAlAABPIAAEkQgBAgAFAfQAFAUAPAAQAOAAAegZQAGgWANgSQATgWAdgEQAegFAQAZQAKAQAIAcQAJAjAFALQAIAPAMgIQAKgHAGgPQAOglADgnQAJg+AAhZIgCiZQABgYgEgYQgDgOgLgHQgRgJgUgDQgLAAgHgGQgKgHgBgMQgCgMAHgJQAGgJAKAAIHmAAQAKAAAGAJQALANgHARQgGAQgSAAQgXADgSAIQgMAGgCAOQgEAZABAZIAAFdQgBAYAEAXQACAOAMAGQAUAJASACIAAgBQAZAAAEAcQADAcgZAAIkYAAQgYAAADgcQACgcAWAAQAWgBAUgJQAMgFADgOQAEgYgBgYIAAl8QAAgQgDgRQgDgJgKgCQgQgCgXAAIgrAAQgWgBgVAFQgNAEgCANQgEAXABAXIAAC6QAABEgIBNQgJBDgjA3QgdAtg4AJQgMACgKAAQgqAAgcgggAl5AZQg4AuAAA4QgBAfARAZQANAWAcAAQAYgBATgNQAWgOAKgXQAMgegCgeIABhBQAAg3gMAAQgHAAhEAzg");
	this.shape_1.setTransform(290.6493,122.0921);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AkgHYQgaAAAAgXQAAgYAdgGQAogGAMgUQALgPABgSIAAo3QAAg1gHgVQgHgTgcgDQgIAAgKgCQgMgDgCgMQgCgKAIgKQAEgFAGgCIAMgEQAwgNAhgRQA4gcAfgoIALgOQALgMAKAGQAIAGABAQIABBEQAmglAbgRQAogYAoAAQBBAAAzApQA2AtAbBCQAeBKgBBNQABBagjBPQgfBLhAAwQg6AshKAAQguAAgpgRIgHgDQgEgBgFAAQgHAAAAAqIAACdQAAARAKAQQALAUAkAGQAhAHAAAXQAAAXgYAAgAgzlBQgGAKAAAfIAAEFQAACXBGAAQAXAAAUgKQAUgKANgSQAggpAMg0QAOg5gBg2QAAg5gNg6QgLg1gggtQgMgSgTgLQgUgLgXAAQgpAAgaAqg");
	this.shape_2.setTransform(435.9516,135.4277);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AjJEyQg/giAAhUQAAg5AhgsQAcglA1ghICchfQAPgJACgDQABgDAAgTIAAg2QAAgtgFgVQgLgpgeAAQgvAAgdBVQgHAYgKASQgRAdg/ATQhCAVAAguQAAgfAYgmQATggAcgZQBPhGB0AAQBUAAAqAiQAsAlAABPIAAEkQAAAgAFAfQAFAUAPAAQAPgCALgLIAMgKQAIgGAFAAQAOAAAAATQAAAXgbAcQg6A9g6AAQgaACgWgRQgVgVgJgdQgDgLgHgNQgFgKgHAHIgaAbQgeAfglAXQgnAXgkAAQgcAAgbgOgAg9AfQg4AtAAA4QgBAfAQAZQAPAXAbgBQAXgBATgNQAVgOALgXQALgdgBgfIABhBQAAg3gMAAQgIAAhCA0g");
	this.shape_3.setTransform(379.525,121.6462);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AkRIAQgxgRgegnQgfgpAAgxQAAhBAyguQAyguBHAAQBHAAAyAuQAyAuAABBQAAA3gkArQBugtBRieQBFiFAOiJQAEgfACgZQhYCmhagLQgegEgugcQhAgmgLgFQgqgSg5AYIgfAOQgJAFAEgHQA7hfAughQAmgbAmAMQAMADA5AhQAtAaAnABQAcAAAsgSQAYgKAjgSQACh4glhiQgjhhg4ghQg8gjg5A2QhCA+gxClIkBAAQAfhfBIhTQBKhVBegrQBngvBlAPQByARBhBdQBdBVAfCTQAfCTgqCVQguChh0BuQiDB8jEAhQgaAFgZAAQg/AAg6gag");
	this.shape_4.setTransform(123.8082,109.9538);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ACjCsQmKgzqGksQE0A6CNAWQD6AoDDAKQHvAYFuidQhyFtm3AAQhMAAhWgLg");
	this.shape_5.setTransform(295.625,214.9762);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00963E").s().p("AG4TmQj9gzlWh4QmKiSjEhHQlZh8jwg2QmvhflLBKQlzBUkeEuQABpsCvoBQDLpVGOk6QFNkGG5giQCxgODmATQCIAMEfAmQG3A7DeAYQGAAoD2gCQCxgBBlgWQCYghBjhdQgCBXg1BxQgzBshFBMQDrAECAgEQDdgICvgiQHNhbDnkjQBBIch+H9Qh+H6kiF0QjiEgk2CtQk7CvlkAfQhMAHhQAAQjVAAjrgvg");
	this.shape_6.setTransform(275.0202,130.1103);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,550,260.2), null);


(lib.БАДнеявляетсялекарственнымсредством = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2E0D18").s().p("ANQDsIAAg5Ig9AAIAAA5IgDAAIAAhGIAIAAQAFgSABg1IAFlHIAmAAIAAGOIALAAIAABGgAMiBgQgBA1gFARIAqAAIAAmCIggAAgAvUDsIAAg5Ig9AAIAAA5IgEAAIAAhGIAIAAQAGgSAAg0IAFlIIAnAAIAAGOIAKAAIAABGgAwDBgQgBA0gEASIApAAIAAmCIgfAAgAQgCXQgFgbAAgvIAAjQQAAguAFgbQAHgfAMAAQAYAAABBoIAADQQgBBpgYAAQgMgBgHgegAQfiEIAADSQgBBcAVAAQAVAAAAhcIAAjSQAAhcgVABQgVgBABBcgANhBNIAAjQQAAhoAXAAQAYAAABBoIAAAgIgEAAIAAghQAAhcgVABQgUgBAABcIAADSQAABbAUAAQAVAAAAhbIAAgtIAEAAIAAAsQgBBpgYAAQgXAAAAhpgAJgBNIAAjQQAAhoAYAAQAYAAAABoIAAAgIgEAAIAAghQABhcgVABQgUgBAABcIAADSQAABbAUAAQAVAAgBhbIAAgtIAEAAIAAAsQAABpgYAAQgYAAAAhpgABDCXQgGgbAAgvIAAjQQAAguAGgbQAGgfAMAAQAYAAAABoIAAAgIgEAAIAAghQABhcgVABQgUgBAABcIAADSQAABbAUAAQAVAAgBhbIAAgtIAEAAIAAAsQAABpgYAAQgMgBgGgegAmXCXQgFgbAAgvIAAjQQAAguAFgbQAHgfAMAAQAYAAAABoIAAAgIgDAAIAAghQAAhcgVABQgUgBAABcIAADSQAABbAUAAQAVAAAAhbIAAgtIADAAIAAAsQAABpgYAAQgMgBgHgegAqcC0IAAgNQAKAAADgcQACgPAAgsIAEk4IAoAAIAAGbIgEAAIAAmPIggAAIgEEsQAAAvgDAUQgEAfgLACgAkICzIAAgMQAKAAADgcQACgPABgsIADk4IAoAAIAAGbIgEAAIAAmPIggAAIgEEsQAAAvgDAUQgEAfgLABgASYCzIAAmIIgcGGIgDAAIgdmGIAAGIIgEAAIAAmbIAHAAIAbGFIAcmFIAGAAIAAGbgAPfCzIAAmbIAXAAQAMAAAFAWQAFAUAAArIAAAaQAAAmgDASQgEAVgJAFQASAJAABOIAAAkQAABfgYAAgAPiCmIAUAAQAUABABhTIAAglQAAgsgGgSQgGgSgMAAIgRAAgAPigtIAQAAQAMAAAFgOQAGgQgBgsIAAgbQAAgmgDgRQgFgTgKAAIgUAAgAO1CzIAAmPIgZAAIAAgMIA2AAIAAAMIgYAAIAAGPgALXCzIAAmbIAsAAIAAAMIgnAAIAAC5IAhAAIAAALIghAAIAAC+IAnAAIAAANgAKdCzIAAmbIAWAAQAYAAAABkIAAAoQAABggaAAIgRAAIAACvgAKggHIARAAQAMgBAFgTQAFgUABgsIAAgqQAAhXgVAAIgTAAgAI2CzIAAmIIgcGGIgEAAIgcmGIAAGIIgEAAIAAmbIAGAAIAcGFIAcmFIAGAAIAAGbgAHmCzIAAmbIADAAIAAGbgAGsCzIAAmbIAEAAIAACuIAQAAQAaAAAABgIAAAqQAABjgXAAgAGwCmIATAAQATABABhXIAAgqQAAgrgGgUQgFgUgMAAIgQAAgAGbCzIAAjIIgpAAIAADIIgEAAIAAmbIAEAAIAADIIApAAIAAjIIAEAAIAAGbgAFdCzIAAjIIgpAAIAADIIgEAAIAAmbIAEAAIAADIIApAAIAAjIIAEAAIAAGbgAD4CzIAAmbIArAAIAAAMIgnAAIAAC5IAhAAIAAALIghAAIAAC+IAnAAIAAANgAC7CzIAAmbIAYAAQAMAAAFAWQAFAUgBArIAAAaQAAAmgDASQgDAVgJAFQASAJAABOIAAAkQAABfgYAAgAC/CmIAUAAQAVABgBhTIAAglQAAgrgFgTQgGgSgMAAIgRAAgAC/gtIAPAAQANAAAEgOQAGgQAAgsIAAgbQAAgmgEgRQgEgTgKAAIgUAAgACTCzIAAmPIgaAAIAAgMIA2AAIAAAMIgZAAIAAGPgAADCzIAAmbIAWAAQAYAAAABkIAAAoQAABggbAAIgQAAIAACvgAAGgHIAQAAQAMgBAGgTQAGgUAAgsIAAgqQgBhXgUAAIgTAAgAgNCzIgHhhIgoAAIgHBhIgDAAIAcmbIAEAAIAdGbgAgUBGIgUkgIgTEgIAnAAgAhWCzIgljMIgJAuIAACeIgEAAIAAmbIAEAAIAADoIArjoIADAAIgjDCIAmDZgAjACzIAAmbIArAAIAAAMIgnAAIAAC5IAhAAIAAALIghAAIAAC+IAnAAIAAANgAkxCzIAAi+IgPAAQgMABgFAOQgIASAAArIAABBQABAYgDAZIgFAAQAEgXAAgaIAAhBQAAhHASgKQgSgMAAhLIAAglQAAhcAXAAIAXAAIAAGbgAlZiLIAAAmQABAtAGASQAGAPAMAAIAPAAIAAjFIgUAAQgTAAgBBRgAnFCzIAAmPIgZAAIAAgMIA2AAIAAAMIgZAAIAAGPgAoWCzIAAmbIAsAAIAAAMIgoAAIAAC5IAhAAIAAALIghAAIAAC+IAoAAIAAANgAonCzIAAi+IgNAAQgNABgFAOQgIASABArIAABBQgBAYgCAZIgFAAQAFgZgBgYIAAhBQAAhHASgKQgSgMAAhLIAAglQgBhcAYAAIAXAAIAAGbgApNiLIAAAmQAAAtAGASQAGAPANAAIANAAIAAjFIgTAAQgTAAAABRgArXCzIAAmbIAWAAQANAAAEAWQAFAUABArIAAAaQAAAmgEASQgDAVgJAFQASAJAABOIAAAkQAABfgZAAgArUCmIATAAQAWABAAhTIAAglQgBgrgFgTQgGgSgMAAIgRAAgArUgtIAPAAQAMAAAGgOQAFgQAAgsIAAgbQAAgmgEgRQgEgTgLAAIgTAAgAroCzIAAi+IgPAAQgZABAABLIAABBQABAXgDAaIgEAAQAEgZgBgYIAAhBQAAhHASgKQgSgMAAhLIAAglQAAhcAYAAIAWAAIAAGbgAsQiLIAAAmQAAAtAHASQAGAPAMAAIAPAAIAAjFIgTAAQgUAAgBBRgAtnCzIAAmbIArAAIAAAMIgoAAIAAC5IAiAAIAAALIgiAAIAAC+IAoAAIAAANgAt4CzIAAjIIgqAAIAADIIgDAAIAAmbIADAAIAADIIAqAAIAAjIIADAAIAAGbgAvECzIAAg+IARAAIAAA+gAwkCzIgHhhIgpAAIgHBhIgDAAIAbmbIAGAAIAcGbgAwsBGIgUkgIgUEgIAoAAgAybCzIAAmbIAsAAIAAAMIgoAAIAACoIASAAQANAAAHATQAGAVABAvIAAAvQAABggaABgAyXCmIATAAQAWABAAhUIAAgxQAAgpgGgSQgFgQgMAAIgSAAg");
	this.shape.setTransform(118,23.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.БАДнеявляетсялекарственнымсредством, new cjs.Rectangle(0,0,236,47.2), null);


(lib.Анимация30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.fon1();
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-200,240,400);


(lib.Анимация29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.fon1();
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-200,240,400);


(lib.Анимация28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("ApbBqQgsAAgfgfQgfggABgrQAAgrAfgfQAfgfArAAIS1AAQAsgBAfAfQAgAfAAAsQABAsgfAfQgfAfgtAAg");
	this.shape.setTransform(0.025,0.0246);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.9,-10.6,141.9,21.299999999999997);


(lib.Анимация27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("ApbBqQgsAAgfgfQgfggABgrQAAgrAfgfQAfgfArAAIS1AAQAsgBAfAfQAgAfAAAsQABAsgfAfQgfAfgtAAg");
	this.shape.setTransform(0.025,0.0246);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.9,-10.6,141.9,21.299999999999997);


(lib.Анимация26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABpAyQgIgFgFgKQgFgLAAgLQAAgKAFgKQAEgJAJgGQAUgLAVALQAJAGAFAJQAJAUgJAWQgEAJgKAGQgKAFgLAAQgKAAgKgFgABtgFQgHAHABALQgBALAHAJQAGAIALAAQALAAAGgIQAFgIAAgMQABgKgGgJQgHgIgKABIgDAAQgJAAgFAIgAj5A3QgIAAgHgDQgFgDgEgGQgDgGAAgGQAAgJAFgFQAFgHAJgCIAQgDIATgDQAAgGgFgFQgFgFgIABQgGAAgFADQgFADgDAGIgOgEQACgKAJgGQAKgHAMABQAKAAAJADQAHAEAEAIIACAIIABA5IgOAAIAAgMQgKAOgQAAIgCAAgAj6ATQgFACgCADQgEADAAAEQAAAFAEADQAEAEAHgBQAFABAGgDQAEgCADgEQADgCABgFIACgMgAHgAyQgIgFgGgKQgFgJAAgMQAAgMAFgJQAFgKAJgFQAIgFAMAAQAMAAAJAFQAJAHADAJQAFALgBANIg7AAQAAAJAGAIQAHAGAJAAQAPABAGgOIAOAFQgDAKgKAGQgKAGgLAAQgMAAgJgFgAHlgIQgGAGgBAIIArAAQgDgUgRAAIgDAAQgHAAgGAGgAAKAsQgKgNAAgRIAAgNIABgOIADgMIAGgKIAIgHQAHgFAHgBIARgDIAQgDIACAOIgVADIgLACIgJAEQgGAEgCAGQgEAHAAAGQAEgGAIgDQAHgDAHAAQAKgBAIAFQAIAFAEAJQAEAJAAAJQAAALgFAKQgFAJgIAEQgIAFgMAAQgQAAgKgLgAAVAAQgFAHAAAKQAAAJAFAIQAGAHAKAAQAJABAGgIQAGgIAAgJQAAgKgGgHQgGgGgJAAIgDAAQgHAAgGAGgAmvAyIAAAAQgJgGgFgHIAMgIQAEAFAGADQAFAEAHAAQAHAAAFgEQAFgDgBgGQABgDgDgDIgHgDIgKgBIgHAAIAAgMIAHAAQAGAAAGgCQAFgCAAgFQAAgFgEgCQgFgEgFABQgHAAgFADQgGACgEAEIgJgKQAHgHAIgDQAHgDAKAAQAHAAAHACQAHAEADAEQAEAFAAAIQAAAJgHAGQAFADACAFQADAGAAAFQAAAHgFAGQgFAHgGACQgHADgJAAQgLAAgJgFgACvA1IAAgNQAFABADgDQADgDABgHIAFg1IA4AAIAABOIgPAAIAAhAIgcAAIgFAuQAAAGgEAGQgCAEgGACIgFABIgIgBgAFfA1IAAhOIAOAAIAABAIAZAAIAAhAIAPAAIAABAIAYAAIAAhAIAPAAIAABOgAEOA1IAAhOIAPAAIAAAaIAXAAIAHABQAJACAGAGQAFAHAAAKQABAJgGAHQgGAHgIACIgHABgAEdAoIAaAAIAGgEQADgEAAgFQAAgFgDgDQgCgEgFgBIgEAAIgVAAgAhtA1IAAhOIAPAAIAAAaIAXAAIAHABQAJACAGAGQAFAHAAAKQABAJgGAHQgGAHgIACIgHABgAheAoIAaAAQAEgCACgDQADgDAAgFQABgKgLgDIgEAAIgVAAgAimA1IAAhAIgbAAIAAgOIBFAAIAAAOIgbAAIAABAgAk0A1IAAggIgnAAIAAAgIgPAAIAAhOIAPAAIAAAfIAnAAIAAgfIAPAAIAABOgAoBA1IAOgcIglhMIARAAIAcA8IAcg8IAQAAIgxBog");
	this.shape.setTransform(0.0341,0.0375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.6,-5.4,107.30000000000001,10.9);


(lib.Анимация25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABpAyQgIgFgFgKQgFgLAAgLQAAgKAFgKQAEgJAJgGQAUgLAVALQAJAGAFAJQAJAUgJAWQgEAJgKAGQgKAFgLAAQgKAAgKgFgABtgFQgHAHABALQgBALAHAJQAGAIALAAQALAAAGgIQAFgIAAgMQABgKgGgJQgHgIgKABIgDAAQgJAAgFAIgAj5A3QgIAAgHgDQgFgDgEgGQgDgGAAgGQAAgJAFgFQAFgHAJgCIAQgDIATgDQAAgGgFgFQgFgFgIABQgGAAgFADQgFADgDAGIgOgEQACgKAJgGQAKgHAMABQAKAAAJADQAHAEAEAIIACAIIABA5IgOAAIAAgMQgKAOgQAAIgCAAgAj6ATQgFACgCADQgEADAAAEQAAAFAEADQAEAEAHgBQAFABAGgDQAEgCADgEQADgCABgFIACgMgAHgAyQgIgFgGgKQgFgJAAgMQAAgMAFgJQAFgKAJgFQAIgFAMAAQAMAAAJAFQAJAHADAJQAFALgBANIg7AAQAAAJAGAIQAHAGAJAAQAPABAGgOIAOAFQgDAKgKAGQgKAGgLAAQgMAAgJgFgAHlgIQgGAGgBAIIArAAQgDgUgRAAIgDAAQgHAAgGAGgAAKAsQgKgNAAgRIAAgNIABgOIADgMIAGgKIAIgHQAHgFAHgBIARgDIAQgDIACAOIgVADIgLACIgJAEQgGAEgCAGQgEAHAAAGQAEgGAIgDQAHgDAHAAQAKgBAIAFQAIAFAEAJQAEAJAAAJQAAALgFAKQgFAJgIAEQgIAFgMAAQgQAAgKgLgAAVAAQgFAHAAAKQAAAJAFAIQAGAHAKAAQAJABAGgIQAGgIAAgJQAAgKgGgHQgGgGgJAAIgDAAQgHAAgGAGgAmvAyIAAAAQgJgGgFgHIAMgIQAEAFAGADQAFAEAHAAQAHAAAFgEQAFgDgBgGQABgDgDgDIgHgDIgKgBIgHAAIAAgMIAHAAQAGAAAGgCQAFgCAAgFQAAgFgEgCQgFgEgFABQgHAAgFADQgGACgEAEIgJgKQAHgHAIgDQAHgDAKAAQAHAAAHACQAHAEADAEQAEAFAAAIQAAAJgHAGQAFADACAFQADAGAAAFQAAAHgFAGQgFAHgGACQgHADgJAAQgLAAgJgFgACvA1IAAgNQAFABADgDQADgDABgHIAFg1IA4AAIAABOIgPAAIAAhAIgcAAIgFAuQAAAGgEAGQgCAEgGACIgFABIgIgBgAFfA1IAAhOIAOAAIAABAIAZAAIAAhAIAPAAIAABAIAYAAIAAhAIAPAAIAABOgAEOA1IAAhOIAPAAIAAAaIAXAAIAHABQAJACAGAGQAFAHAAAKQABAJgGAHQgGAHgIACIgHABgAEdAoIAaAAIAGgEQADgEAAgFQAAgFgDgDQgCgEgFgBIgEAAIgVAAgAhtA1IAAhOIAPAAIAAAaIAXAAIAHABQAJACAGAGQAFAHAAAKQABAJgGAHQgGAHgIACIgHABgAheAoIAaAAQAEgCACgDQADgDAAgFQABgKgLgDIgEAAIgVAAgAimA1IAAhAIgbAAIAAgOIBFAAIAAAOIgbAAIAABAgAk0A1IAAggIgnAAIAAAgIgPAAIAAhOIAPAAIAAAfIAnAAIAAgfIAPAAIAABOgAoBA1IAOgcIglhMIARAAIAcA8IAcg8IAQAAIgxBog");
	this.shape.setTransform(0.0341,0.0375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.6,-5.4,107.30000000000001,10.9);


(lib.Анимация24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("Aj4BkIATgzIguhuIAeAAIAeBLIAdhLIAcAAIhAChgAmGBkIAAihIAZAAIAAAGQAFgFAIgCQAJgDAHAAQAQABAMAHQANAJAFANQAOAfgOAcQgFANgNAJQgLAHgQABIgOgDQgIgCgFgDIAAA2gAlngeQgMAZAMAYQAGAKAOgBQAHABAIgGQAFgEAEgIQACgJAAgHQAAgJgDgIQgDgIgGgEQgHgGgIABIgDAAQgKAAgGAJgAMqAvQgNgGgIgMIAWgPQAFAFAIAEQAIAEAHAAQAHAAAGgEQAFgEAAgGQAAgEgEgEQgEgCgGAAIgSAAIAAgVIAGAAQAIABAIgDQAGgBAAgHQAAgGgEgCQgGgCgEAAQgIAAgIADIgNAHIgQgTQALgIAKgEQALgFAOgBQAKAAAKAFQAJACAHAIQAGAJAAAKQAAAMgIALQAGAFADAFQACAHAAAHQABALgHAKQgHAIgKAEQgLAFgMAAQgPAAgOgHgAK0AuQgOgJgHgNQgPgdAPgfQAIgOANgHQAdgQAeAQQANAHAHAOQAPAegPAfQgIAOgMAHQgOAHgPABQgQgBgOgHgAK9gdQgHAMABAMQgBALAHAMQAIAJALAAQALABAJgIIABgCQAIgLAAgMQABgNgJgLQgHgKgMABIgDAAQgLAAgHAJgADtAuQgNgHgHgOQgIgOAAgPQgBgQAJgPQAGgOANgIQAOgIAQAAQARAAANAJQANAIAGAQQAGARgDARIhPAAQACAKAGAJQAIAGALAAQASABAFgPIAcAIQgFAPgOAJQgOAJgRAAQgPAAgPgIgADwgSIAyAAQgBgJgGgIQgGgFgKAAQgWAAgFAWgAiDAvQgNgGgHgMIAVgPQAHAGAHADQAHAEAHAAQAIAAAGgEQAEgEAAgGQAAgFgDgDQgEgCgGAAIgSAAIAAgVIAHAAQAHABAHgDQADAAACgCQACgDAAgDQgBgGgEgCQgGgCgEAAQgHAAgIADIgOAHIgQgTQALgIALgEQAKgFAOgBQAKAAALAFQAJACAGAIQAHAJgBAKQAAAIgBAEQgBAEgGAHQAGAFADAFQADAIAAAGQABALgHAKQgGAIgLAEQgLAFgNAAQgOAAgPgHgApSAvQgMgFgJgNIAXgPQAEAFAIAEQAIAEAHAAQAIAAAFgEQAFgEAAgGQABgFgFgDQgEgCgGAAIgSAAIAAgVIAHAAQAIABAHgDQAHgBgBgHQABgGgFgCQgGgCgEAAQgIAAgIADIgNAHIgQgTQAKgIALgEQAMgFANgBQAKAAAKAFQAKACAGAIQAHAKgBAJQAAAHgCAFQgCAGgEAFQAGAEADAGQADAHAAAHQAAAMgHAJQgGAIgLAEQgKAFgNAAQgPAAgOgHgArNAwQgIgEgFgHQgEgJgBgJQAAgMAHgJQAHgJALgDIAwgJQAAgIgGgEQgHgEgHAAQgHAAgHAEQgGADgDAHIgagIQAFgOALgJQAPgJASAAQANAAANAFQATAIACAUIABBSIgZAAIAAgNQgGAIgKAEQgLAEgLABQgLgBgJgFgAq3AGQgFACgEAEQgDADAAAFQABAEAEAEQAFADAGAAQAGAAAHgCIAJgHIAEgGIACgJIABgIgAOPAyIAAhvIBRAAIAAAaIg1AAIAABVgAJlAyIAAg3IgfA3IgKAAIgeg3IAAA3IgbAAIAAhvIAXAAIAoBIIAmhIIAYAAIAABvgACAAyIAAhXIgkAAIAAgYIBlAAIAAAYIglAAIAABXgAAqAyIAAhDIgxBDIgXAAIAAhvIAbAAIAABBIAyhBIAWAAIAABvgAntAyIAAhvIBRAAIAAAaIg1AAIAABVgAtiAyIAAiVIA/AAIANABQATABAKAPQALAQgBARQABARgLAPQgKAPgTABIgvABIAAAygAtFgaIAhAAIAKgBQAFgCAEgDQADgEABgFQADgIgDgJQgBgEgDgEQgEgEgFgBIgKgCIghAAgAGDAdIAcgiIgcgjIAOgLIAlAuIglAtgAFWAdIAcgiIgcgjIAOgLIAlAuIglAtgAuzgFIAmguIAOALIgcAjIAcAiIgOALgAvfgFIAlguIAOALIgcAjIAcAiIgOALg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-99.2,-10,198.4,20);


(lib.Анимация23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("Aj4BkIATgzIguhuIAeAAIAeBLIAdhLIAcAAIhAChgAmGBkIAAihIAZAAIAAAGQAFgFAIgCQAJgDAHAAQAQABAMAHQANAJAFANQAOAfgOAcQgFANgNAJQgLAHgQABIgOgDQgIgCgFgDIAAA2gAlngeQgMAZAMAYQAGAKAOgBQAHABAIgGQAFgEAEgIQACgJAAgHQAAgJgDgIQgDgIgGgEQgHgGgIABIgDAAQgKAAgGAJgAMqAvQgNgGgIgMIAWgPQAFAFAIAEQAIAEAHAAQAHAAAGgEQAFgEAAgGQAAgEgEgEQgEgCgGAAIgSAAIAAgVIAGAAQAIABAIgDQAGgBAAgHQAAgGgEgCQgGgCgEAAQgIAAgIADIgNAHIgQgTQALgIAKgEQALgFAOgBQAKAAAKAFQAJACAHAIQAGAJAAAKQAAAMgIALQAGAFADAFQACAHAAAHQABALgHAKQgHAIgKAEQgLAFgMAAQgPAAgOgHgAK0AuQgOgJgHgNQgPgdAPgfQAIgOANgHQAdgQAeAQQANAHAHAOQAPAegPAfQgIAOgMAHQgOAHgPABQgQgBgOgHgAK9gdQgHAMABAMQgBALAHAMQAIAJALAAQALABAJgIIABgCQAIgLAAgMQABgNgJgLQgHgKgMABIgDAAQgLAAgHAJgADtAuQgNgHgHgOQgIgOAAgPQgBgQAJgPQAGgOANgIQAOgIAQAAQARAAANAJQANAIAGAQQAGARgDARIhPAAQACAKAGAJQAIAGALAAQASABAFgPIAcAIQgFAPgOAJQgOAJgRAAQgPAAgPgIgADwgSIAyAAQgBgJgGgIQgGgFgKAAQgWAAgFAWgAiDAvQgNgGgHgMIAVgPQAHAGAHADQAHAEAHAAQAIAAAGgEQAEgEAAgGQAAgFgDgDQgEgCgGAAIgSAAIAAgVIAHAAQAHABAHgDQADAAACgCQACgDAAgDQgBgGgEgCQgGgCgEAAQgHAAgIADIgOAHIgQgTQALgIALgEQAKgFAOgBQAKAAALAFQAJACAGAIQAHAJgBAKQAAAIgBAEQgBAEgGAHQAGAFADAFQADAIAAAGQABALgHAKQgGAIgLAEQgLAFgNAAQgOAAgPgHgApSAvQgMgFgJgNIAXgPQAEAFAIAEQAIAEAHAAQAIAAAFgEQAFgEAAgGQABgFgFgDQgEgCgGAAIgSAAIAAgVIAHAAQAIABAHgDQAHgBgBgHQABgGgFgCQgGgCgEAAQgIAAgIADIgNAHIgQgTQAKgIALgEQAMgFANgBQAKAAAKAFQAKACAGAIQAHAKgBAJQAAAHgCAFQgCAGgEAFQAGAEADAGQADAHAAAHQAAAMgHAJQgGAIgLAEQgKAFgNAAQgPAAgOgHgArNAwQgIgEgFgHQgEgJgBgJQAAgMAHgJQAHgJALgDIAwgJQAAgIgGgEQgHgEgHAAQgHAAgHAEQgGADgDAHIgagIQAFgOALgJQAPgJASAAQANAAANAFQATAIACAUIABBSIgZAAIAAgNQgGAIgKAEQgLAEgLABQgLgBgJgFgAq3AGQgFACgEAEQgDADAAAFQABAEAEAEQAFADAGAAQAGAAAHgCIAJgHIAEgGIACgJIABgIgAOPAyIAAhvIBRAAIAAAaIg1AAIAABVgAJlAyIAAg3IgfA3IgKAAIgeg3IAAA3IgbAAIAAhvIAXAAIAoBIIAmhIIAYAAIAABvgACAAyIAAhXIgkAAIAAgYIBlAAIAAAYIglAAIAABXgAAqAyIAAhDIgxBDIgXAAIAAhvIAbAAIAABBIAyhBIAWAAIAABvgAntAyIAAhvIBRAAIAAAaIg1AAIAABVgAtiAyIAAiVIA/AAIANABQATABAKAPQALAQgBARQABARgLAPQgKAPgTABIgNABIgiAAIAAAygAtFgaIAhAAIAKgBQAFgCAEgDQADgEABgFQADgIgDgJQgBgEgDgEQgEgEgFgBIgKgCIghAAgAGDAdIAcgiIgcgjIAOgLIAlAuIglAtgAFWAdIAcgiIgcgjIAOgLIAlAuIglAtgAuzgFIAmguIAOALIgcAjIAcAiIgOALgAvfgFIAlguIAOALIgcAjIAcAiIgOALg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-99.2,-10,198.4,20);


(lib.Анимация22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AvmBiQgpAAgdgdQgcgcAAgoQAAgoAcgdQAdgdApAAIfOAAQAoAAAdAdQAcAdAAAoQAAAogcAcQgdAdgoAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-9.7,219.4,19.5);


(lib.Анимация21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AvmBiQgpAAgdgdQgcgcAAgoQAAgoAcgdQAdgdApAAIfOAAQAoAAAdAdQAcAdAAAoQAAAogcAcQgdAdgoAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-9.7,219.4,19.5);


(lib.Анимация20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AvmBiQgpAAgdgdQgcgcAAgoQAAgoAcgdQAdgdApAAIfOAAQAoAAAdAdQAcAdAAAoQAAAogcAcQgdAdgoAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-9.7,219.4,19.5);


(lib.Анимация19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AvmBiQgpAAgdgdQgcgcAAgoQAAgoAcgdQAdgdApAAIfOAAQAoAAAdAdQAcAdAAAoQAAAogcAcQgdAdgoAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-9.7,219.4,19.5);


(lib.Анимация18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AvmBiQgpAAgdgdQgcgcAAgoQAAgoAcgdQAdgdApAAIfOAAQAoAAAdAdQAcAdAAAoQAAAogcAcQgdAdgoAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-9.7,219.4,19.5);


(lib.Анимация17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AvmBiQgpAAgdgdQgcgcAAgoQAAgoAcgdQAdgdApAAIfOAAQAoAAAdAdQAcAdAAAoQAAAogcAcQgdAdgoAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.7,-9.7,219.4,19.5);


(lib.Анимация16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiaAzQgFgDgDgGQgDgGAAgGQgBgIAFgHQAFgGAIgDIAhgGQAAgEgEgDQgFgDgFAAQgFAAgEACQgFADgCAFIgSgHQAEgKAIgFQAKgHAMABQAKgBAJAEQAIADAEAIIADAIIAAA6IgRAAIAAgKQgFAGgHADQgGACgJABQgJAAgGgDgAh+AlIAGgFIADgFQACgCAAgDIAAgGIgXAEQgEACgCADQgFAFAGAGQAEADAEgBQADABAGgCgADJA0IAAhOIAUAAIAAAZIAUAAIAIABQAJAAAGAIQAHAIgBAJQABAJgHAIQgGAHgJACIgIABgADdAlIAPAAIAGgBQAEgBABgEQADgCAAgEQAAgIgIgDIgDgBIgSAAgACMA0IAAg8IgZAAIAAgSIBHAAIAAASIgaAAIAAA8gABPA0IAAgZIgPAAIgPAZIgUAAIARgcQgIgDgDgGQgFgHABgIQgBgIAGgJQAGgHAKgBIAIgBIAnAAIAABOgAA6gKQgDABgCADQgCACAAAEQAAAEACADQADADADAAIADABIARAAIAAgWIgOAAgAgHA0IAAgoIgVAoIgHAAIgVgoIAAAoIgTAAIAAhOIAQAAIAcAyIAbgyIAPAAIAABOgAjLA0IAAhWIgvAAIAABWIgTAAIAAhpIBWAAIAABpg");
	this.shape.setTransform(0.0067,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-5.3,54,10.7);


(lib.Анимация15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiaAzQgFgDgDgGQgDgGAAgGQgBgIAFgHQAFgGAIgDIAhgGQAAgEgEgDQgFgDgFAAQgFAAgEACQgFADgCAFIgSgHQAEgKAIgFQAKgHAMABQAKgBAJAEQAIADAEAIIADAIIAAA6IgRAAIAAgKQgFAGgHADQgGACgJABQgJAAgGgDgAh+AlIAGgFIADgFQACgCAAgDIAAgGIgXAEQgEACgCADQgFAFAGAGQAEADAEgBQADABAGgCgADJA0IAAhOIAUAAIAAAZIAUAAIAIABQAJAAAGAIQAHAIgBAJQABAJgHAIQgGAHgJACIgIABgADdAlIAPAAIAGgBQAEgBABgEQADgCAAgEQAAgIgIgDIgDgBIgSAAgACMA0IAAg8IgZAAIAAgSIBHAAIAAASIgaAAIAAA8gABPA0IAAgZIgPAAIgPAZIgUAAIARgcQgIgDgDgGQgFgHABgIQgBgIAGgJQAGgHAKgBIAIgBIAnAAIAABOgAA6gKQgDABgCADQgCACAAAEQAAAEACADQADADADAAIADABIARAAIAAgWIgOAAgAgHA0IAAgoIgVAoIgHAAIgVgoIAAAoIgTAAIAAhOIAQAAIAcAyIAbgyIAPAAIAABOgAjLA0IAAhWIgvAAIAABWIgTAAIAAhpIBWAAIAABpg");
	this.shape.setTransform(0.0067,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-5.3,54,10.7);


(lib.Анимация14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AGyAxQgKgFgEgKQgLgVALgVQAEgJAKgFQAVgLAVALQAJAFAEAJQAMAVgMAVQgEAKgJAFQgLAGgKAAQgKAAgLgGgAG5gDQgGAHABAJQgBAIAGAJQAFAFAHABQAIAAAHgFIABgCQAGgHgCgJQACgKgGgGQgFgHgKABIgBAAQgHAAgFAGgACdAxQgJgGgEgJQgFgKAAgLQAAgLAFgKQAFgJAJgFQAVgLAUALQAKAFAFAJQAKAVgKAVQgGAKgJAFQgKAGgLAAQgKAAgLgGgACkgDQgEAHAAAJQgBAJAFAIQAGAFAIABQAIAAAFgFIACgCQAFgIAAgIQAAgJgFgHQgGgHgIABIgDAAQgHAAgFAGgAgSAxQgJgFgGgKQgEgJAAgMQAAgMAEgJQAGgJAJgFQAUgMAUAMQAKAFAFAJQAKAVgKAVQgGAKgJAFQgKAGgLAAQgJAAgKgGgAgMgDQgEAHAAAJQAAAKAEAHQAGAFAHABQAHAAAGgFIACgCQAEgGAAgKQAAgKgEgGQgGgHgJABIgBAAQgHAAgFAGgAkiAxQgJgFgFgKQgFgLAAgKQAAgMAFgJQAFgJAKgFQAUgLAVALQAIAFAGAJQALAVgLAVQgGAKgIAFQgKAGgLAAQgKAAgLgGgAkbgDQgFAGAAAKQAAAKAFAHQAGAFAHABQAIAAAFgFIACgCQAFgGAAgKQABgJgGgHQgFgHgJABIgCAAQgIAAgEAGgAnMAxQgKgFgEgKQgKgVAKgVQAFgJAJgFQAVgLAUALQAKAFAFAJQALAVgLAVQgFAKgKAFQgKAGgKAAQgKAAgLgGgAnGgDQgFAIABAIQgBAJAGAIQAFAFAIABQAIAAAFgFIACgCQAFgGAAgKQAAgKgFgGQgFgHgJABIgCAAQgIAAgFAGgAIOAxQgJgFgEgKQgGgMABgJQgBgKAGgLQAEgJAJgFQAJgGAMAAQANAAAKAHQAKAHADANIgUAEQgBgFgFgEQgGgEgHABQgGABgFAFQgFAHABAJQgBAJAFAHQAFAIAJgBQAGABAEgEQAEgEABgFIAVAEQgDAMgKAIQgKAGgNAAQgNAAgIgFgAD6AxQgHgEgGgJQgEgKgBgKIAAgOQAAgHACgIIADgNIAGgJIAIgHQAIgFAGgBIARgDIARgDIACASIgeAEQgHABgCACQgFADgDAGQgDAFAAAGQAEgGAHgDQAHgCAFAAQALAAAHAFQAJAFADAIQAEAJAAAJQAAAMgFAIQgFAJgJAFQgHAEgNAAQgLAAgIgFgAEBADQgFAHABAHQgBAHAFAHQAGAFAHAAQAHAAAGgFQAFgHgBgHQABgIgGgGQgEgEgIAAQgHAAgGAEgABJAxQgKgGgEgJQgEgKAAgLQAAgMAEgJQAFgJAJgFQAJgGAMAAQANgBAKAIQAKAHACANIgUAEQgBgFgFgEQgFgEgHABQgHABgEAFQgEAHgBAJQAAAIAFAIQAFAIAIgBQAHABAEgEQADgDACgGIAUAEQgCAMgKAIQgKAGgOAAQgLAAgJgFgAjGAxQgJgGgEgJQgFgKAAgLQAAgMAFgJQAEgIAKgGQAIgGAMAAQANAAALAHQAJAIADAMIgUAEQgCgFgEgEQgGgEgGABQgIABgDAFQgFAHAAAJQAAAKAFAGQAFAIAIgBQAGABAEgEQAEgDACgGIAUAEQgDAMgKAIQgKAGgNAAQgMAAgJgFgAomAxIAAABQgHgFgGgJQgEgKgBgKIAAgOIACgPQAAgHADgGIAGgJIAIgHQAHgFAHgBIAQgDIASgDIACASIgfAEIgIADQgEADgFAGQgCAGAAAFQADgFAIgEQAGgCAGAAQALAAAHAFQAJAFADAIQAEAJAAAJQAAAMgFAIQgGAKgIAEQgHAEgNAAQgLAAgIgFgAofADQgEAGAAAIQgBAIAFAGQAGAFAHAAQAIAAAEgFQAGgHgBgHQABgHgGgHQgEgEgIAAQgIAAgFAEgAqDAzQgGgDgDgFQgDgGAAgGQgBgJAFgGQAFgHAJgCIANgEIAUgDQAAgEgEgDQgEgDgGAAIgKACQgEACgCAGIgSgGQACgJAJgHQAKgHANABQAKAAAIAEQAIADAEAIIADAIIABA5IgSAAIAAgJQgFAFgGAEQgGACgJAAQgIAAgHgDgAprATIgJACQgDABgDADQgCADAAADQABADACACIAAABQAEACAEAAQAGAAAEgCIAGgFIADgEIACgGIAAgGgAKmA0IAAhOIAUAAIAAAaIAcAAQAJABAHAHQAFAHABALQgBAKgFAGQgHAIgJABIgHABgAK6AlIASAAIAEgBQADgBACgDQACgEAAgEQgBgFgDgDIgEgBIgDgBIgSAAgAJqA0IAAg8IgaAAIAAgSIBIAAIAAASIgaAAIAAA8gAF6A0IAAgeIghAAIAAAeIgUAAIAAhOIAUAAIAAAeIAhAAIAAgeIAUAAIAABOgAhLA0IAAg7IgeAAIAAA7IgUAAIAAhOIBGAAIAABOgAlsA0IAAg8IgaAAIAAgSIBHAAIAAASIgZAAIAAA8gArqA0IAAhoIA1ABQANABAHAKQAHALAAAMQAAAMgHAJQgHALgNABIgGAAIgDABIgZAAIAAAjgArXgBIAYAAIAGgBQAFgBABgCQADgCAAgEIABgGIgBgGQgBgEgCgCIgGgEIgDAAIgbAAg");
	this.shape.setTransform(0,0.0125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.7,-5.4,149.5,10.9);


(lib.Анимация13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AGyAxQgKgFgEgKQgLgVALgVQAEgJAKgFQAVgLAVALQAJAFAEAJQAMAVgMAVQgEAKgJAFQgLAGgKAAQgKAAgLgGgAG5gDQgGAHABAJQgBAIAGAJQAFAFAHABQAIAAAHgFIABgCQAGgHgCgJQACgKgGgGQgFgHgKABIgBAAQgHAAgFAGgACdAxQgJgGgEgJQgFgKAAgLQAAgLAFgKQAFgJAJgFQAVgLAUALQAKAFAFAJQAKAVgKAVQgGAKgJAFQgKAGgLAAQgKAAgLgGgACkgDQgEAHAAAJQgBAJAFAIQAGAFAIABQAIAAAFgFIACgCQAFgIAAgIQAAgJgFgHQgGgHgIABIgDAAQgHAAgFAGgAgSAxQgJgFgGgKQgEgJAAgMQAAgMAEgJQAGgJAJgFQAUgMAUAMQAKAFAFAJQAKAVgKAVQgGAKgJAFQgKAGgLAAQgJAAgKgGgAgMgDQgEAHAAAJQAAAKAEAHQAGAFAHABQAHAAAGgFIACgCQAEgGAAgKQAAgKgEgGQgGgHgJABIgBAAQgHAAgFAGgAkiAxQgJgFgFgKQgFgLAAgKQAAgMAFgJQAFgJAKgFQAUgLAVALQAIAFAGAJQALAVgLAVQgGAKgIAFQgKAGgLAAQgKAAgLgGgAkbgDQgFAGAAAKQAAAKAFAHQAGAFAHABQAIAAAFgFIACgCQAFgGAAgKQABgJgGgHQgFgHgJABIgCAAQgIAAgEAGgAnMAxQgKgFgEgKQgKgVAKgVQAFgJAJgFQAVgLAUALQAKAFAFAJQALAVgLAVQgFAKgKAFQgKAGgKAAQgKAAgLgGgAnGgDQgFAIABAIQgBAJAGAIQAFAFAIABQAIAAAFgFIACgCQAFgGAAgKQAAgKgFgGQgFgHgJABIgCAAQgIAAgFAGgAIOAxQgJgFgEgKQgGgMABgJQgBgKAGgLQAEgJAJgFQAJgGAMAAQANAAAKAHQAKAHADANIgUAEQgBgFgFgEQgGgEgHABQgGABgFAFQgFAHABAJQgBAJAFAHQAFAIAJgBQAGABAEgEQAEgEABgFIAVAEQgDAMgKAIQgKAGgNAAQgNAAgIgFgAD6AxQgHgEgGgJQgEgKgBgKIAAgOQAAgHACgIIADgNIAGgJIAIgHQAIgFAGgBIARgDIARgDIACASIgeAEQgHABgCACQgFADgDAGQgDAFAAAGQAEgGAHgDQAHgCAFAAQALAAAHAFQAJAFADAIQAEAJAAAJQAAAMgFAIQgFAJgJAFQgHAEgNAAQgLAAgIgFgAEBADQgFAHABAHQgBAHAFAHQAGAFAHAAQAHAAAGgFQAFgHgBgHQABgIgGgGQgEgEgIAAQgHAAgGAEgABJAxQgKgGgEgJQgEgKAAgLQAAgMAEgJQAFgJAJgFQAJgGAMAAQANgBAKAIQAKAHACANIgUAEQgBgFgFgEQgFgEgHABQgHABgEAFQgEAHgBAJQAAAIAFAIQAFAIAIgBQAHABAEgEQADgDACgGIAUAEQgCAMgKAIQgKAGgOAAQgLAAgJgFgAjGAxQgJgGgEgJQgFgKAAgLQAAgMAFgJQAEgIAKgGQAIgGAMAAQANAAALAHQAJAIADAMIgUAEQgCgFgEgEQgGgEgGABQgIABgDAFQgFAHAAAJQAAAKAFAGQAFAIAIgBQAGABAEgEQAEgDACgGIAUAEQgDAMgKAIQgKAGgNAAQgMAAgJgFgAomAxIAAABQgHgFgGgJQgEgKgBgKIAAgOIACgPQAAgHADgGIAGgJIAIgHQAHgFAHgBIAQgDIASgDIACASIgfAEIgIADQgEADgFAGQgCAGAAAFQADgFAIgEQAGgCAGAAQALAAAHAFQAJAFADAIQAEAJAAAJQAAAMgFAIQgGAKgIAEQgHAEgNAAQgLAAgIgFgAofADQgEAGAAAIQgBAIAFAGQAGAFAHAAQAIAAAEgFQAGgHgBgHQABgHgGgHQgEgEgIAAQgIAAgFAEgAqDAzQgGgDgDgFQgDgGAAgGQgBgJAFgGQAFgHAJgCIANgEIAUgDQAAgEgEgDQgEgDgGAAIgKACQgEACgCAGIgSgGQACgJAJgHQAKgHANABQAKAAAIAEQAIADAEAIIADAIIABA5IgSAAIAAgJQgFAFgGAEQgGACgJAAQgIAAgHgDgAprATIgJACQgDABgDADQgCADAAADQABADACACIAAABQAEACAEAAQAGAAAEgCIAGgFIADgEIACgGIAAgGgAKmA0IAAhOIAUAAIAAAaIAcAAQAJABAHAHQAFAHABALQgBAKgFAGQgHAIgJABIgHABgAK6AlIASAAIAEgBQADgBACgDQACgEAAgEQgBgFgDgDIgEgBIgDgBIgSAAgAJqA0IAAg8IgaAAIAAgSIBIAAIAAASIgaAAIAAA8gAF6A0IAAgeIghAAIAAAeIgUAAIAAhOIAUAAIAAAeIAhAAIAAgeIAUAAIAABOgAhLA0IAAg7IgeAAIAAA7IgUAAIAAhOIBGAAIAABOgAlsA0IAAg8IgaAAIAAgSIBHAAIAAASIgZAAIAAA8gArqA0IAAhoIA1ABQANABAHAKQAHALAAAMQAAAMgHAJQgHALgNABIgGAAIgDABIgZAAIAAAjgArXgBIAYAAIAGgBQAFgBABgCQADgCAAgEIABgGIgBgGQgBgEgCgCIgGgEIgDAAIgbAAg");
	this.shape.setTransform(0,0.0125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.7,-5.4,149.5,10.9);


(lib.Анимация12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABmBGIAAhxIASAAIAAAFQAEgEAFgBQAIgCADAAQALAAAJAGQAJAGAEAIQAKAWgKAUQgEAIgIAHQgJAGgKgBIgLgBIgJgDIAAAlgAB9gUQgJARAJAQQAFAIAIgCQAHACAEgFQADgDADgFIACgLQAAgFgCgHQgDgFgEgEQgFgDgGAAIgCAAQgHAAgDAHgAFbA0IAAgRIhCAAIAAhOIAUAAIAAA7IAfAAIAAg7IAUAAIAAA8IAPAAIAAAjgAjCA0IAAgRIhBAAIAAhOIAUAAIAAA7IAfAAIAAg7IAUAAIAAA8IAOAAIAAAjgAmuAgQgKgFgFgKQgEgKAAgKQgBgKAFgMQAGgKAJgEQAUgMAVAMQAJAFAFAJQALAWgLAUQgFAKgJAFQgKAFgLAAQgKAAgKgFgAmogUQgFAIAAAJQAAAHAFAJQAFAFAIABQAIABAGgGIACgBQAFgIgBgIQABgJgFgIQgHgHgIABIgCAAQgHAAgFAGgADLAiQgGgDgDgGQgDgFAAgGQgBgJAGgGQAEgGAIgDIAigGQgBgGgDgCQgGgDgFAAQgFAAgEACQgFADgCAFIgSgFQAEgLAIgFQAKgHAMAAQALAAAIAEQAIADAEAIQACADABAGIABA4IgSAAIAAgKQgFAHgGACQgIADgIAAQgIAAgGgDgADaAEIgGAEQgEAGAFAFIABAAQADADAEAAQAFAAAEgCIAGgEIADgEIADgGIAAgGgAiRAgQgJgFgGgJQgFgLAAgJQAAgLAFgMQAFgJAKgFQAKgGAKAAQALAAAKAGQAJAGAEALQAFALgCAMIg3AAQABAJAEAFQAGAEAHAAQAMABAFgLIAUAGQgFAKgKAHQgJAFgMAAQgLABgKgGgAiIgXQgGADgBAIIAjAAQgBgIgEgEQgFgEgGAAIgBAAQgHAAgEAFgAIGAjIAAgZIgOAAIgQAZIgUAAIARgcQgHgCgEgGQgEgGgBgJQAAgJAHgIQAFgHAKgBIAIgCIAoAAIAABOgAHxgbQgDABgCAEQgCADAAADQgBAFAEACQABADAEABIAGABIAOAAIAAgYIgOAAgAGwAjIAAgvIgkAvIgQAAIAAhOIATAAIAAAuIAjguIAQAAIAABOgAAqAjIAAg8IgaAAIAAgSIBIAAIAAASIgaAAIAAA8gAgSAjIAAgeIghAAIAAAeIgTAAIAAhOIATAAIAAAfIAhAAIAAgfIATAAIAABOgAktAjIAAgeIgfAAIAAAeIgUAAIAAhOIAUAAIAAAfIAfAAIAAgfIAVAAIAABOgAncAjIgqguIAAAuIgUAAIAAhoIAUAAIAAAxIAogxIAYAAIgsA0IAvA0g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.8,-7,107.69999999999999,14);


(lib.Анимация11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABmBGIAAhxIASAAIAAAFQAEgEAFgBQAIgCADAAQALAAAJAGQAJAGAEAIQAKAWgKAUQgEAIgIAHQgJAGgKgBIgLgBIgJgDIAAAlgAB9gUQgJARAJAQQAFAIAIgCQAHACAEgFQADgDADgFIACgLQAAgFgCgHQgDgFgEgEQgFgDgGAAIgCAAQgHAAgDAHgAFbA0IAAgRIhCAAIAAhOIAUAAIAAA7IAfAAIAAg7IAUAAIAAA8IAPAAIAAAjgAjCA0IAAgRIhBAAIAAhOIAUAAIAAA7IAfAAIAAg7IAUAAIAAA8IAOAAIAAAjgAmuAgQgKgFgFgKQgEgKAAgKQgBgKAFgMQAGgKAJgEQAUgMAVAMQAJAFAFAJQALAWgLAUQgFAKgJAFQgKAFgLAAQgKAAgKgFgAmogUQgFAIAAAJQAAAHAFAJQAFAFAIABQAIABAGgGIACgBQAFgIgBgIQABgJgFgIQgHgHgIABIgCAAQgHAAgFAGgADLAiQgGgDgDgGQgDgFAAgGQgBgJAGgGQAEgGAIgDIAigGQgBgGgDgCQgGgDgFAAQgFAAgEACQgFADgCAFIgSgFQAEgLAIgFQAKgHAMAAQALAAAIAEQAIADAEAIQACADABAGIABA4IgSAAIAAgKQgFAHgGACQgIADgIAAQgIAAgGgDgADaAEIgGAEQgEAGAFAFIABAAQADADAEAAQAFAAAEgCIAGgEIADgEIADgGIAAgGgAiRAgQgJgFgGgJQgFgLAAgJQAAgLAFgMQAFgJAKgFQAKgGAKAAQALAAAKAGQAJAGAEALQAFALgCAMIg3AAQABAJAEAFQAGAEAHAAQAMABAFgLIAUAGQgFAKgKAHQgJAFgMAAQgLABgKgGgAiIgXQgGADgBAIIAjAAQgBgIgEgEQgFgEgGAAIgBAAQgHAAgEAFgAIGAjIAAgZIgOAAIgQAZIgUAAIARgcQgHgCgEgGQgEgGgBgJQAAgJAHgIQAFgHAKgBIAIgCIAoAAIAABOgAHxgbQgDABgCAEQgCADAAADQgBAFAEACQABADAEABIAGABIAOAAIAAgYIgOAAgAGwAjIAAgvIgkAvIgQAAIAAhOIATAAIAAAuIAjguIAQAAIAABOgAAqAjIAAg8IgaAAIAAgSIBIAAIAAASIgaAAIAAA8gAgSAjIAAgeIghAAIAAAeIgTAAIAAhOIATAAIAAAfIAhAAIAAgfIATAAIAABOgAktAjIAAgeIgfAAIAAAeIgUAAIAAhOIAUAAIAAAfIAfAAIAAgfIAVAAIAABOgAncAjIgqguIAAAuIgUAAIAAhoIAUAAIAAAxIAogxIAYAAIgsA0IAvA0g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.8,-7,107.69999999999999,14);


(lib.Анимация10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AoIBZQgWgNgKgXQgMgZAAgcQAAgbAMgZQAKgXAWgNQAYgMAbAAQAaAAAYAMQAVAMALAYQAMAZAAAbQAAAcgMAZQgKAXgWANQgYAMgaAAQgbAAgYgMgAoAgwQgNATAAAdQAAAeANASQAOASAdABQAbABAOgTQAOgTAAgeQAAgegOgSQgOgRgbgBQgcAAgPASgAKxBhIAAhCIgpAAIggBCIgqAAIAkhIQgSgIgHgPQgIgQAAgSQgBgXANgTQAMgRAbgFIAIAAIBagBIAADCgAJ4g9QgGACgFAFQgEAGgBAFQgEALAEALQABAGAEAFQAEAEAHADIAHABIAyAAIAAg8IgsAAgAH4BhIAAiBIhUCBIgmAAIAAjCIAmAAIAACBIBUiBIAlAAIAADCgADPBhIAAjCIBOAAQASAAAQAJQAMAHAHAOQAFAMAAANQAAANgEAKQgFAKgJAFQAOAEAHAMQAGANAAANQABAZgPASQgPAQgdAAgAD0A/IAtAAQALAAAIgHQAHgIAAgLQAAgKgGgHQgJgIgLABIgtAAgAD0gVIApAAQAHABAIgFQAHgGgBgKQABgJgGgGQgIgHgIABIgpAAgACBBhIAAiBIhVCBIglAAIAAjCIAlAAIAACBIBViBIAmAAIAADCgAhGBhIAAhQIhXAAIAABQIgkAAIAAjCIAkAAIAABRIBXAAIAAhRIAlAAIAADCgAlZBhIAAjCIB/AAIAAAjIhaAAIAACfgApjBhIhNhYIAABYIglAAIAAjCIAlAAIAABaIBKhaIAtAAIhSBhIBXBhg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.6,-10.1,145.2,20.299999999999997);


(lib.Анимация9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AoIBZQgWgNgKgXQgMgZAAgcQAAgbAMgZQAKgXAWgNQAYgMAbAAQAaAAAYAMQAVAMALAYQAMAZAAAbQAAAcgMAZQgKAXgWANQgYAMgaAAQgbAAgYgMgAoAgwQgNATAAAdQAAAeANASQAOASAdABQAbABAOgTQAOgTAAgeQAAgegOgSQgOgRgbgBQgcAAgPASgAKxBhIAAhCIgpAAIggBCIgqAAIAkhIQgSgIgHgPQgIgQAAgSQgBgXANgTQAMgRAbgFIAIAAIBagBIAADCgAJ4g9QgGACgFAFQgEAGgBAFQgEALAEALQABAGAEAFQAEAEAHADIAHABIAyAAIAAg8IgsAAgAH4BhIAAiBIhUCBIgmAAIAAjCIAmAAIAACBIBUiBIAlAAIAADCgADPBhIAAjCIBOAAQASAAAQAJQAMAHAHAOQAFAMAAANQAAANgEAKQgFAKgJAFQAOAEAHAMQAGANAAANQABAZgPASQgPAQgdAAgAD0A/IAtAAQALAAAIgHQAHgIAAgLQAAgKgGgHQgJgIgLABIgtAAgAD0gVIApAAQAHABAIgFQAHgGgBgKQABgJgGgGQgIgHgIABIgpAAgACBBhIAAiBIhVCBIglAAIAAjCIAlAAIAACBIBViBIAmAAIAADCgAhGBhIAAhQIhXAAIAABQIgkAAIAAjCIAkAAIAABRIBXAAIAAhRIAlAAIAADCgAlZBhIAAjCIB/AAIAAAjIhaAAIAACfgApjBhIhNhYIAABYIglAAIAAjCIAlAAIAABaIBKhaIAtAAIhSBhIBXBhg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.6,-10.1,145.2,20.299999999999997);


(lib.Анимация8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AoxCyQgHgEgGgJQgEgHAAgKQgBgLAIgKQAGgKAMgDQAMgEAIgBIAbgEQAAgHgFgFQgHgEgIABQgHAAgGADQgHADgDAHIgZgIQADgNANgKQAPgJARABQAOAAANAEQAMAFAFALQADAHABAGIAABSIgYAAIAAgNQgHAIgJAEQgKAEgNAAQgMAAgIgEgAobCHIgJAGQgCADAAAFQABAFADADQAFADAHAAQAGAAAGgDQAGgCADgEIAFgGIACgIIAAgJgAsGCwIAAAAQgNgGgHgMIAVgPQAIAHAGADQAHADAHAAQAIAAAGgEQAFgDgBgGQABgGgFgCQgDgCgGAAIgSAAIAAgXIAGAAQAIABAHgCQADgBACgCQACgDgBgDQAAgFgEgDQgFgCgFAAQgIAAgHADIgOAIIgQgUQAMgIAKgEQALgFAOAAQALAAAJAEQAJADAHAIQAFAIAAALQAAAGgBAFQgBAEgGAHQAHAFACAGQADAIAAAHQABAKgHAKQgGAIgMAEQgJAEgOAAQgPAAgOgGgAt8CvQgNgIgHgNQgHgPAAgQQAAgQAHgPQAIgNAMgIQAegQAeAQQAMAIAIANQAPAfgPAfQgHANgNAIQgOAHgQAAQgQAAgOgHgAtzBjQgGAMAAAMQgBANAIALQAHAJALAAQAMABAIgIIACgCQAIgLgBgNQABgNgIgLQgIgKgMABIgCAAQgLAAgIAJgAqhCzIAAhwIBRAAIAAAaIg0AAIAABWgAvLCzIAAg4IgeA4IgKAAIgeg4IAAA4IgbAAIAAhwIAWAAIAoBJIAnhJIAXAAIAABwgAE3AVIAAihIAZAAIAAAGQAFgFAHgCQAJgDAIAAQAPAAANAIQAMAIAGANQAOAfgOAeQgGAOgMAHQgLAIgQAAQgJAAgGgCQgHgBgFgEIAAA1gAFVhtQgGAMABANQgBAMAGANQAHAKANgBQAJABAGgGQAFgEAEgIQACgHAAgKQAAgJgDgIQgCgIgHgFQgIgFgHABIgCAAQgLAAgGAJgAgigDIAAgZIhEAAIAAAZIgbAAIAAgvQAIABAFgHQAFgLABgLIAEg+IBXAAIAABaIAMAAIAAAvgAhUhLIgCAPQgDAGgDAEIAtAAIAAhFIgiAAgAmJggQgNgIgHgNQgPgfAPgfQAHgOANgHQAOgIAQAAQAPAAAOAIQAOAHAGAOQAPAfgPAfQgGANgOAIQgOAIgPAAQgPAAgPgIgAmAhsQgGALAAANQgBAOAIAKQAHAIALABQALAAAJgHIACgCIAAgBQAHgKAAgNQAAgNgHgLQgIgKgMABIgDAAQgLAAgHAJgAJlgZQgOABgNgIQgLgHgHgMQgHgPAAgOIgBgUIADgWQABgLADgHQAFgIAEgGQAFgFAHgFQAIgGAMgDIAXgEIAagEIADAZIgOACIgQACIgPACQgHACgGADQgHAFgDAIQgEAHgBAJQAGgJAKgEQAIgEAKAAQAOgBAMAIQAKAIAHAMQAFAMAAAOQAAARgHAMQgHANgNAHQgMAGgNAAIgEAAgAJVhjQgIAJACALQgBANAHAIQAHAIALgBQALABAHgJQAHgIgBgMQABgLgHgJQgHgHgLAAQgLAAgHAHgALLggQgNgIgHgNQgPgfAPgfQAHgOANgHQAOgIAQAAQAPAAAOAIQANAHAIAOQAPAfgPAfQgIANgNAIQgOAHgPAAQgQAAgOgHgALUhsQgGALgBANQAAAOAIAKQAHAIALABQALAAAJgHIACgCIAAgBQAHgLAAgMQAAgNgHgLQgIgKgNABIgCAAQgLAAgHAJgAHGgdQgIgFgGgIQgDgJAAgIQgBgMAGgJQAIgKALgDIAUgFIAcgEQAAgIgGgEQgHgEgHAAQgHAAgHADQgGADgDAIIgagIQAFgOAMgJQAOgKASABQAOAAAMAFQATAIADAUIAABTIgZAAIAAgOQgGAIgKAFQgKAEgMAAQgLAAgJgEgAHtgyQAEgBAFgFQACgCACgEIADgJIAAgJIgWAEIgLAEQgFABgEAEQgDADAAAFQAAAFAEAEQAHADAFAAQAHAAAGgDgAuGgdQgIgFgFgIQgEgIgBgJQAAgMAHgJQAHgKAMgDIAUgFIAbgEQABgHgHgFQgGgFgIABQgHAAgGADQgHADgDAIIgagIQAFgOALgJQAPgKASABQAOAAANAFQALAEAGAMQADAHAAAFIABBTIgZAAIAAgOQgGAJgKAEQgKAEgMAAQgLAAgJgEgAtfgyQAEgCAFgEIAFgGQACgFgBgEIABgJIghAIQgFABgEAEQgDAEAAAFQABAEAEADIAAABQAGADAGAAQAGAAAGgDgAAAgcIAAgYQAJACAEgEQAFgHAAgHIAGhIIBVAAIAABwIgcAAIAAhWIgfAAIgFAsIgCAMQgEAVgJAHQgGAEgJAAQgHAAgIgCgAQRgcIAAhwIAcAAIAABwgAOriMIAdAAIAAAjIAUABIALABQAOACAJAKQAIALgBAOQABAOgIAKQgJAJgOAEIgLABIgxAAgAPIgyIAMAAIAJgBQAFgBADgEQADgEAAgGQABgMgMgEIgEgBIgRAAgANUgcIAAhXIglAAIAAgZIBmAAIAAAZIglAAIAABXgADPgcIAAgkIgVAAIgVAkIgfAAIAZgoQgKgEgGgIQgHgKACgMQgCgOAJgLQAKgKANgCIALgBIA4AAIAABwgACxh2QgEACgEAEQgDAFAAAFQAAAFADAFQAFAEAEABIAEABIAZAAIAAghIgVAAgAjWgcIgng2IAAA2IgcAAIAAhwIAcAAIAAA2IAmg2IAjAAIgoA4IArA4gAnzgcIAAhXIglAAIAAgZIBmAAIAAAZIgkAAIAABXgApJgcIAAhFIgyBFIgXAAIAAhwIAbAAIAABCIAzhCIAWAAIAABwgArOgcIAAhWIgrAAIAABWIgdAAIAAhwIBlAAIAABwgAvNgcIAAg+IhCAAIAAA+IgdAAIAAiWIAdAAIAAA+IBCAAIAAg+IAcAAIAACWg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.9,-18.2,213.8,36.5);


(lib.Анимация7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#760160").s().p("AoxCyQgHgEgGgJQgEgHAAgKQgBgLAIgKQAGgKAMgDQAMgEAIgBIAbgEQAAgHgFgFQgHgEgIABQgHAAgGADQgHADgDAHIgZgIQADgNANgKQAPgJARABQAOAAANAEQAMAFAFALQADAHABAGIAABSIgYAAIAAgNQgHAIgJAEQgKAEgNAAQgMAAgIgEgAobCHIgJAGQgCADAAAFQABAFADADQAFADAHAAQAGAAAGgDQAGgCADgEIAFgGIACgIIAAgJgAsGCwIAAAAQgNgGgHgMIAVgPQAIAHAGADQAHADAHAAQAIAAAGgEQAFgDgBgGQABgGgFgCQgDgCgGAAIgSAAIAAgXIAGAAQAIABAHgCQADgBACgCQACgDgBgDQAAgFgEgDQgFgCgFAAQgIAAgHADIgOAIIgQgUQAMgIAKgEQALgFAOAAQALAAAJAEQAJADAHAIQAFAIAAALQAAAGgBAFQgBAEgGAHQAHAFACAGQADAIAAAHQABAKgHAKQgGAIgMAEQgJAEgOAAQgPAAgOgGgAt8CvQgNgIgHgNQgHgPAAgQQAAgQAHgPQAIgNAMgIQAegQAeAQQAMAIAIANQAPAfgPAfQgHANgNAIQgOAHgQAAQgQAAgOgHgAtzBjQgGAMAAAMQgBANAIALQAHAJALAAQAMABAIgIIACgCQAIgLgBgNQABgNgIgLQgIgKgMABIgCAAQgLAAgIAJgAqhCzIAAhwIBRAAIAAAaIg0AAIAABWgAvLCzIAAg4IgeA4IgKAAIgeg4IAAA4IgbAAIAAhwIAWAAIAoBJIAnhJIAXAAIAABwgAE3AVIAAihIAZAAIAAAGQAFgFAHgCQAJgDAIAAQAPAAANAIQAMAIAGANQAOAfgOAeQgGAOgMAHQgLAIgQAAQgJAAgGgCQgHgBgFgEIAAA1gAFVhtQgGAMABANQgBAMAGANQAHAKANgBQAJABAGgGQAFgEAEgIQACgHAAgKQAAgJgDgIQgCgIgHgFQgIgFgHABIgCAAQgLAAgGAJgAgigDIAAgZIhEAAIAAAZIgbAAIAAgvQAIABAFgHQAFgLABgLIAEg+IBXAAIAABaIAMAAIAAAvgAhUhLIgCAPQgDAGgDAEIAtAAIAAhFIgiAAgAmJggQgNgIgHgNQgPgfAPgfQAHgOANgHQAOgIAQAAQAPAAAOAIQAOAHAGAOQAPAfgPAfQgGANgOAIQgOAIgPAAQgPAAgPgIgAmAhsQgGALAAANQgBAOAIAKQAHAIALABQALAAAJgHIACgCIAAgBQAHgKAAgNQAAgNgHgLQgIgKgMABIgDAAQgLAAgHAJgAJlgZQgOABgNgIQgLgHgHgMQgHgPAAgOIgBgUIADgWQABgLADgHQAFgIAEgGQAFgFAHgFQAIgGAMgDIAXgEIAagEIADAZIgOACIgQACIgPACQgHACgGADQgHAFgDAIQgEAHgBAJQAGgJAKgEQAIgEAKAAQAOgBAMAIQAKAIAHAMQAFAMAAAOQAAARgHAMQgHANgNAHQgMAGgNAAIgEAAgAJVhjQgIAJACALQgBANAHAIQAHAIALgBQALABAHgJQAHgIgBgMQABgLgHgJQgHgHgLAAQgLAAgHAHgALLggQgNgIgHgNQgPgfAPgfQAHgOANgHQAOgIAQAAQAPAAAOAIQANAHAIAOQAPAfgPAfQgIANgNAIQgOAHgPAAQgQAAgOgHgALUhsQgGALgBANQAAAOAIAKQAHAIALABQALAAAJgHIACgCIAAgBQAHgLAAgMQAAgNgHgLQgIgKgNABIgCAAQgLAAgHAJgAHGgdQgIgFgGgIQgDgJAAgIQgBgMAGgJQAIgKALgDIAUgFIAcgEQAAgIgGgEQgHgEgHAAQgHAAgHADQgGADgDAIIgagIQAFgOAMgJQAOgKASABQAOAAAMAFQATAIADAUIAABTIgZAAIAAgOQgGAIgKAFQgKAEgMAAQgLAAgJgEgAHtgyQAEgBAFgFQACgCACgEIADgJIAAgJIgWAEIgLAEQgFABgEAEQgDADAAAFQAAAFAEAEQAHADAFAAQAHAAAGgDgAuGgdQgIgFgFgIQgEgIgBgJQAAgMAHgJQAHgKAMgDIAUgFIAbgEQABgHgHgFQgGgFgIABQgHAAgGADQgHADgDAIIgagIQAFgOALgJQAPgKASABQAOAAANAFQALAEAGAMQADAHAAAFIABBTIgZAAIAAgOQgGAJgKAEQgKAEgMAAQgLAAgJgEgAtfgyQAEgCAFgEIAFgGQACgFgBgEIABgJIghAIQgFABgEAEQgDAEAAAFQABAEAEADIAAABQAGADAGAAQAGAAAGgDgAAAgcIAAgYQAJACAEgEQAFgHAAgHIAGhIIBVAAIAABwIgcAAIAAhWIgfAAIgFAsIgCAMQgEAVgJAHQgGAEgJAAQgHAAgIgCgAQRgcIAAhwIAcAAIAABwgAOriMIAdAAIAAAjIAUABIALABQAOACAJAKQAIALgBAOQABAOgIAKQgJAJgOAEIgLABIgxAAgAPIgyIAMAAIAJgBQAFgBADgEQADgEAAgGQABgMgMgEIgEgBIgRAAgANUgcIAAhXIglAAIAAgZIBmAAIAAAZIglAAIAABXgADPgcIAAgkIgVAAIgVAkIgfAAIAZgoQgKgEgGgIQgHgKACgMQgCgOAJgLQAKgKANgCIALgBIA4AAIAABwgACxh2QgEACgEAEQgDAFAAAFQAAAFADAFQAFAEAEABIAEABIAZAAIAAghIgVAAgAjWgcIgng2IAAA2IgcAAIAAhwIAcAAIAAA2IAmg2IAjAAIgoA4IArA4gAnzgcIAAhXIglAAIAAgZIBmAAIAAAZIgkAAIAABXgApJgcIAAhFIgyBFIgXAAIAAhwIAbAAIAABCIAzhCIAWAAIAABwgArOgcIAAhWIgrAAIAABWIgdAAIAAhwIBlAAIAABwgAvNgcIAAg+IhCAAIAAA+IgdAAIAAiWIAdAAIAAA+IBCAAIAAg+IAcAAIAACWg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.9,-18.2,213.8,36.5);


(lib.Анимация6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.box();
	this.instance.setTransform(-68.7,-99.35,0.7123,0.7123);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.7,-99.3,137.5,198.7);


(lib.Анимация5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.box();
	this.instance.setTransform(-68.7,-99.35,0.7123,0.7123);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.7,-99.3,137.5,198.7);


(lib.Анимация4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.fon();
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-200,240,400);


(lib.Анимация3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.fon();
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-200,240,400);


(lib.Анимация2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABoESIAbhKIhCiiIArAAIArBvIArhvIApAAIhdDsgAhnESIAAjsIAlAAIAAAJQAIgHALgDQAMgEALAAQAWAAASALQARALAKAUQAJAVABAYQAAAXgKAVQgJAUgRALQgSAMgVgBQgKAAgLgCQgLgDgHgFIAABOgAg6BUQgJAQABAUQgBAUAJAQQAJANAUAAQAMABAKgHQAIgGAEgMQAEgLAAgOQAAgPgEgKQgEgLgJgHQgJgHgNAAQgUAAgIAOgAp6ESIAAjsIAlAAIAAAJQAJgHAKgDQAMgEALAAQAWAAATALQASAMAJATQAKAVAAAYQAAAXgKAVQgIATgSAMQgSAMgWgBQgKAAgLgCQgLgEgHgEIAABOgApNBUQgJARABATQgBATAJARQAJANAVAAQAMABAJgHQAJgHAEgLQAEgNAAgMQAAgNgEgMQgEgLgJgHQgJgHgOAAQgUAAgIAOgAIPDDQgTgLgLgTQgLgTAAgYQAAgaALgVQALgUASgLQAVgLAWAAQAZgBATANQATANAIAVQAJAZgDAbIhzAAQABAQALALQAMALAOgBQAZAAAJgVIAqAMQgKAXgUAMQgUAMgXAAIgEAAQgVAAgUgLgAI7BFQghAAgGAgIBIAAQgBgPgJgKQgJgHgLAAIgDAAgAmZDDQgTgLgLgTQgLgUAAgXQAAgYALgXQALgUASgLQAVgLAWAAQAZgBATANQATAOAIAUQAJAZgDAbIhzAAQABAQALALQALALAPgBQAYAAAKgVIAqAMQgKAXgUAMQgUAMgXAAIgEAAQgVAAgUgLgAltBFQghAAgGAgIBIAAQgBgOgJgLQgKgHgLAAIgCAAgAsVDDQgTgLgLgTQgLgTAAgYQAAgaALgVQAKgUATgLQAUgLAXAAQAYgBAUANQASANAJAVQAJAZgDAbIh0AAQACAQAKALQAMALAPgBQAZAAAJgVIApAMQgJAXgUAMQgVAMgXAAIgDAAQgWAAgTgLgArpBFQghAAgGAgIBIAAQgBgPgJgKQgJgHgLAAIgDAAgAOVDKIAAgsIAsAAIAAAsgAMYDKIAAg/IhEAAIAAA/IgpAAIAAikIApAAIAAA+IBEAAIAAg+IApAAIAACkgAGrDKIgzhPIAABPIglAAIAAhPIgyBPIgwAAIA5hSIg1hSIAtAAIAxBPIAAhPIAlAAIAABPIAxhPIAtAAIg1BSIA5BSgAj9DKIAAikIB3AAIAAAmIhOAAIAAB+gAuMDKIAAh+IhAAAIAAB+IgpAAIAAikICSAAIAACkgAOVCOQAAgMADgIQABgJAGgJQADgHAFgFIAKgJIAOgNQAGgHACgHQACgGAAgIIAAgIQgBgFgDgCQgDgFgGgCQgGgCgHAAIgKABQgFABgEADQgJAIABALIgrAAQABgQAIgOQAHgNAMgHQASgMAWAAQASAAAPAFQAaAKAKAZQAJAbgNAXQgHANgMANIgMAMIgIAKQgEAHgBAFIgBAMgAohg7QgTgJgMgRIAggWQAJAJAKAFQALAFALAAQAKAAAJgGQAIgFgBgJQABgHgHgEQgFgEgJAAIgaAAIAAggIAJAAQALAAALgCQAEgBADgEQADgDgBgEQABgIgHgEQgHgEgIAAQgLAAgLAFQgJAEgLAHIgXgcQAQgMAQgHQAPgHAUAAQAPAAAPAFQANAFAKAMQAKANgBAPQAAAIgDAIQgCAJgHAHQAJAIAEAIQAEAKAAALQAAASgJAMQgKAMgPAGQgQAGgSAAQgXAAgTgJgArOg9QgTgLgKgUQgLgVABgYQAAgXAKgWQAKgSATgMQAVgLAXAAQAXAAAUALQASALALAUQALAVAAAYQAAAXgLAWQgLATgSALQgUALgXAAQgXAAgVgLgAqji4QgTAAgKANQgKAQAAATQAAATAKAQQALAMAQABQARAAAMgLIADgDQALgPgBgTQABgTgLgQQgKgNgQAAIgEAAgAmOg2IAAikIB2AAIAAAmIhNAAIAAB+gAtAg2IAAiDIhACDIgPAAIg/iDIAACDIgnAAIAAjbIAlAAIBJCRIBIiRIAlAAIAADbg");
	this.shape.setTransform(0.0091,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.3,-27.4,202.7,54.9);


(lib.Анимация1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABoESIAbhKIhCiiIArAAIArBvIArhvIApAAIhdDsgAhnESIAAjsIAlAAIAAAJQAIgHALgDQAMgEALAAQAWAAASALQARALAKAUQAJAVABAYQAAAXgKAVQgJAUgRALQgSAMgVgBQgKAAgLgCQgLgDgHgFIAABOgAg6BUQgJAQABAUQgBAUAJAQQAJANAUAAQAMABAKgHQAIgGAEgMQAEgLAAgOQAAgPgEgKQgEgLgJgHQgJgHgNAAQgUAAgIAOgAp6ESIAAjsIAlAAIAAAJQAJgHAKgDQAMgEALAAQAWAAATALQASAMAJATQAKAVAAAYQAAAXgKAVQgIATgSAMQgSAMgWgBQgKAAgLgCQgLgEgHgEIAABOgApNBUQgJARABATQgBATAJARQAJANAVAAQAMABAJgHQAJgHAEgLQAEgNAAgMQAAgNgEgMQgEgLgJgHQgJgHgOAAQgUAAgIAOgAIPDDQgTgLgLgTQgLgTAAgYQAAgaALgVQALgUASgLQAVgLAWAAQAZgBATANQATANAIAVQAJAZgDAbIhzAAQABAQALALQAMALAOgBQAZAAAJgVIAqAMQgKAXgUAMQgUAMgXAAIgEAAQgVAAgUgLgAI7BFQghAAgGAgIBIAAQgBgPgJgKQgJgHgLAAIgDAAgAmZDDQgTgLgLgTQgLgUAAgXQAAgYALgXQALgUASgLQAVgLAWAAQAZgBATANQATAOAIAUQAJAZgDAbIhzAAQABAQALALQALALAPgBQAYAAAKgVIAqAMQgKAXgUAMQgUAMgXAAIgEAAQgVAAgUgLgAltBFQghAAgGAgIBIAAQgBgOgJgLQgKgHgLAAIgCAAgAsVDDQgTgLgLgTQgLgTAAgYQAAgaALgVQAKgUATgLQAUgLAXAAQAYgBAUANQASANAJAVQAJAZgDAbIh0AAQACAQAKALQAMALAPgBQAZAAAJgVIApAMQgJAXgUAMQgVAMgXAAIgDAAQgWAAgTgLgArpBFQghAAgGAgIBIAAQgBgPgJgKQgJgHgLAAIgDAAgAOVDKIAAgsIAsAAIAAAsgAMYDKIAAg/IhEAAIAAA/IgpAAIAAikIApAAIAAA+IBEAAIAAg+IApAAIAACkgAGrDKIgzhPIAABPIglAAIAAhPIgyBPIgwAAIA5hSIg1hSIAtAAIAxBPIAAhPIAlAAIAABPIAxhPIAtAAIg1BSIA5BSgAj9DKIAAikIB3AAIAAAmIhOAAIAAB+gAuMDKIAAh+IhAAAIAAB+IgpAAIAAikICSAAIAACkgAOVCOQAAgMADgIQABgJAGgJQADgHAFgFIAKgJIAOgNQAGgHACgHQACgGAAgIIAAgIQgBgFgDgCQgDgFgGgCQgGgCgHAAIgKABQgFABgEADQgJAIABALIgrAAQABgQAIgOQAHgNAMgHQASgMAWAAQASAAAPAFQAaAKAKAZQAJAbgNAXQgHANgMANIgMAMIgIAKQgEAHgBAFIgBAMgAohg7QgTgJgMgRIAggWQAJAJAKAFQALAFALAAQAKAAAJgGQAIgFgBgJQABgHgHgEQgFgEgJAAIgaAAIAAggIAJAAQALAAALgCQAEgBADgEQADgDgBgEQABgIgHgEQgHgEgIAAQgLAAgLAFQgJAEgLAHIgXgcQAQgMAQgHQAPgHAUAAQAPAAAPAFQANAFAKAMQAKANgBAPQAAAIgDAIQgCAJgHAHQAJAIAEAIQAEAKAAALQAAASgJAMQgKAMgPAGQgQAGgSAAQgXAAgTgJgArOg9QgTgLgKgUQgLgVABgYQAAgXAKgWQAKgSATgMQAVgLAXAAQAXAAAUALQASALALAUQALAVAAAYQAAAXgLAWQgLATgSALQgUALgXAAQgXAAgVgLgAqji4QgTAAgKANQgKAQAAATQAAATAKAQQALAMAQABQARAAAMgLIADgDQALgPgBgTQABgTgLgQQgKgNgQAAIgEAAgAmOg2IAAikIB2AAIAAAmIhNAAIAAB+gAtAg2IAAiDIhACDIgPAAIg/iDIAACDIgnAAIAAjbIAlAAIBJCRIBIiRIAlAAIAADbg");
	this.shape.setTransform(0.0091,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.3,-27.4,202.7,54.9);


// stage content:
(lib.Безымянный2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// yznat
	this.instance = new lib.Анимация25("synched",0);
	this.instance.setTransform(120,323.55);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance_1 = new lib.Анимация26("synched",0);
	this.instance_1.setTransform(120,323.55);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(158).to({_off:false},0).to({_off:true,alpha:1},8).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(158).to({_off:false},8).wait(7).to({startPosition:0},0).to({scaleX:0.9084,scaleY:0.9084,y:323.65},5).to({scaleX:1,scaleY:1,y:323.55},5).wait(10).to({startPosition:0},0).to({alpha:0},5).wait(1));

	// pp_4
	this.instance_2 = new lib.Анимация27("synched",0);
	this.instance_2.setTransform(120,324.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_3 = new lib.Анимация28("synched",0);
	this.instance_3.setTransform(120,324.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(158).to({_off:false},0).to({_off:true,alpha:1},8).wait(33));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(158).to({_off:false},8).wait(7).to({startPosition:0},0).to({scaleX:0.9084,scaleY:0.9084},5).to({scaleX:1,scaleY:1},5).wait(10).to({startPosition:0},0).to({alpha:0},5).wait(1));

	// razgryz
	this.instance_4 = new lib.Анимация23("synched",0);
	this.instance_4.setTransform(112.5,57.15);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.instance_5 = new lib.Анимация24("synched",0);
	this.instance_5.setTransform(112.5,57.15);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(142).to({_off:false},0).to({_off:true,alpha:1},11).wait(46));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(142).to({_off:false},11).wait(40).to({startPosition:0},0).to({alpha:0},5).wait(1));

	// rabota
	this.instance_6 = new lib.Анимация13("synched",0);
	this.instance_6.setTransform(-118.95,335);
	this.instance_6._off = true;

	this.instance_7 = new lib.Анимация14("synched",0);
	this.instance_7.setTransform(88.05,335);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(104).to({_off:false},0).to({_off:true,x:88.05},12).wait(83));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(104).to({_off:false},12).wait(20).to({startPosition:0},0).to({x:97.05,alpha:0},6).wait(51).to({startPosition:0},0).to({startPosition:0},5).wait(1));

	// p_3
	this.instance_8 = new lib.Анимация17("synched",0);
	this.instance_8.setTransform(-111.75,336.1);
	this.instance_8._off = true;

	this.instance_9 = new lib.Анимация18("synched",0);
	this.instance_9.setTransform(95.25,336.1);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(104).to({_off:false},0).to({_off:true,x:95.25},12).wait(83));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(104).to({_off:false},12).wait(20).to({startPosition:0},0).to({x:104.25,alpha:0},6).wait(51).to({startPosition:0},0).to({startPosition:0},5).wait(1));

	// koncetrat
	this.instance_10 = new lib.Анимация11("synched",0);
	this.instance_10.setTransform(-90.85,311.1);
	this.instance_10._off = true;

	this.instance_11 = new lib.Анимация12("synched",0);
	this.instance_11.setTransform(67.15,311.1);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(96).to({_off:false},0).to({_off:true,x:67.15},12).wait(91));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(96).to({_off:false},12).wait(28).to({startPosition:0},0).to({x:76.15,alpha:0},6).wait(51).to({startPosition:0},0).to({startPosition:0},5).wait(1));

	// p_2
	this.instance_12 = new lib.Анимация21("synched",0);
	this.instance_12.setTransform(-110.75,311.3);
	this.instance_12._off = true;

	this.instance_13 = new lib.Анимация22("synched",0);
	this.instance_13.setTransform(47.25,311.3);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(96).to({_off:false},0).to({_off:true,x:47.25},12).wait(91));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(96).to({_off:false},12).wait(28).to({startPosition:0},0).to({x:56.25,alpha:0},6).wait(51).to({startPosition:0},0).to({startPosition:0},5).wait(1));

	// pamyat
	this.instance_14 = new lib.Анимация15("synched",0);
	this.instance_14.setTransform(-75.7,285.1);
	this.instance_14._off = true;

	this.instance_15 = new lib.Анимация16("synched",0);
	this.instance_15.setTransform(40.3,285.1);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(87).to({_off:false},0).to({_off:true,x:40.3},12).wait(100));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(87).to({_off:false},12).wait(37).to({startPosition:0},0).to({x:49.3,alpha:0},6).wait(51).to({startPosition:0},0).to({startPosition:0},5).wait(1));

	// p_1
	this.instance_16 = new lib.Анимация19("synched",0);
	this.instance_16.setTransform(-111.15,286.5);
	this.instance_16._off = true;

	this.instance_17 = new lib.Анимация20("synched",0);
	this.instance_17.setTransform(4.85,286.5);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(87).to({_off:false},0).to({_off:true,x:4.85},12).wait(100));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(87).to({_off:false},12).wait(37).to({startPosition:0},0).to({x:13.85,alpha:0},6).wait(51).to({startPosition:0},0).to({startPosition:0},5).wait(1));

	// box
	this.instance_18 = new lib.Анимация5("synched",0);
	this.instance_18.setTransform(86.7,180.35);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.instance_19 = new lib.Анимация6("synched",0);
	this.instance_19.setTransform(105.7,180.35);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(54).to({_off:false},0).to({_off:true,x:105.7,alpha:1},17).wait(128));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(54).to({_off:false},17).wait(71).to({startPosition:0},0).to({scaleX:1.1745,scaleY:1.1745,x:103.7,y:194.35},11).wait(40).to({startPosition:0},0).to({alpha:0},5).wait(1));

	// napitok
	this.instance_20 = new lib.Анимация7("synched",0);
	this.instance_20.setTransform(120.2,65.05);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.instance_21 = new lib.Анимация8("synched",0);
	this.instance_21.setTransform(120.2,65.05);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(63).to({_off:false},0).to({_off:true,alpha:1},15).wait(121));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(63).to({_off:false},15).wait(58).to({startPosition:0},0).to({alpha:0},6).wait(51).to({startPosition:0},0).to({startPosition:0},5).wait(1));

	// kogniv
	this.instance_22 = new lib.Анимация9("synched",0);
	this.instance_22.setTransform(67.9,30.35);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.instance_23 = new lib.Анимация10("synched",0);
	this.instance_23.setTransform(85.9,30.35);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(54).to({_off:false},0).to({_off:true,x:85.9,alpha:1},17).wait(128));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(54).to({_off:false},17).wait(122).to({startPosition:0},0).to({alpha:0},5).wait(1));

	// _Clip_Group_
	this.instance_24 = new lib.ClipGroup();
	this.instance_24.setTransform(204.45,27.05,0.0974,0.0974,0,0,0,275.7,130.8);
	this.instance_24.alpha = 0;
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(54).to({_off:false},0).to({alpha:1},17).wait(122).to({alpha:0},5).wait(1));

	// diskl
	this.instance_25 = new lib.БАДнеявляетсялекарственнымсредством();
	this.instance_25.setTransform(120,376.4,1,1,0,0,0,118,23.6);
	this.instance_25.alpha = 0;
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(33).to({_off:false},0).to({alpha:0.4492},10).wait(150).to({alpha:0},5).wait(1));

	// fon
	this.instance_26 = new lib.Анимация3("synched",0);
	this.instance_26.setTransform(120,200);
	this.instance_26.alpha = 0;
	this.instance_26._off = true;

	this.instance_27 = new lib.Анимация4("synched",0);
	this.instance_27.setTransform(120,200);
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(33).to({_off:false},0).to({_off:true,alpha:1},10).wait(156));
	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(33).to({_off:false},10).wait(150).to({startPosition:0},0).to({alpha:0},5).wait(1));

	// mozg
	this.instance_28 = new lib.Анимация1("synched",0);
	this.instance_28.setTransform(97.35,41.7,0.8179,0.8179);
	this.instance_28.alpha = 0;
	this.instance_28._off = true;

	this.instance_29 = new lib.Анимация2("synched",0);
	this.instance_29.setTransform(114.35,41.7);
	this.instance_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(3).to({_off:false},0).to({_off:true,scaleX:1,scaleY:1,x:114.35,alpha:1},17).wait(179));
	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(3).to({_off:false},17).wait(173).to({startPosition:0},0).to({alpha:0},5).wait(1));

	// fon1
	this.instance_30 = new lib.fon1();

	this.instance_31 = new lib.Анимация29("synched",0);
	this.instance_31.setTransform(120,200);
	this.instance_31._off = true;

	this.instance_32 = new lib.Анимация30("synched",0);
	this.instance_32.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_30}]}).to({state:[{t:this.instance_31}]},193).to({state:[{t:this.instance_32}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(193).to({_off:false},0).to({_off:true},5).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-101.4,200,341.4,200);
// library properties:
lib.properties = {
	id: 'CB463BF80B1CF04882B930A49951E931',
	width: 240,
	height: 400,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_P_1.png", id:"index_atlas_P_1"},
		{src:"images/index_atlas_NP_1.jpg", id:"index_atlas_NP_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['CB463BF80B1CF04882B930A49951E931'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;